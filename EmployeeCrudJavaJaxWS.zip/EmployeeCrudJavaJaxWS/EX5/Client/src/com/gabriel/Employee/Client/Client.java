package com.gabriel.Employee.Client;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.gabriel.employee.fx.Employee;
import com.gabriel.employee.fx.EmployeeFx;

public class Client {

	public static void main(String[] args) throws MalformedURLException {
		URL url = new URL("http://localhost:8001/employee?wsdl");
		QName qname = new QName("http://Impl.Employee.gabriel.com/", "EmployeeImplService");
		Service service = Service.create(url,qname);

		EmployeeFx employee = service.getPort(EmployeeFx.class);
		Employee emp = new Employee();
		
		try (Scanner input  = new Scanner(System.in)) {
			
			while(true) {
				System.out.println("Employee Logging System");
				System.out.println("[A] CREATE EMPLOYEE");
				System.out.println("[B] DELETE EMPLOYEE");
				System.out.println("[C] UPDATE EMPLOYEE ");
				System.out.println("[D] VIEW EMPLOYEE DETAILS");
				System.out.println("[E] VIEW ALL EMPLOYEE DETAILS");
				
				System.out.println("[ENTER CHOICE]: ");
				String choice = input.nextLine();
				
				switch(choice) {
				case "A": // Create an employee
					emp = new Employee();
					System.out.println("-- CREATE EMPLOYEE --");
					System.out.println("Enter Employee ID: ");
					emp.setId(input.nextLine());
					System.out.println("Enter Employee Number: ");
					emp.setEmployeeNumber(input.nextLine());
					System.out.println("Enter Employee Name: ");
					emp.setName(input.nextLine());
					employee.createEmployee(emp);
					break;
					
				case "B": // Delete an employee
					System.out.println("-- DELETE EMPLOYEE --");
					System.out.println("Enter Employee ID: ");
					employee.removeEmployee(input.nextLine());
					break;
					
				case "C": // Update an employee
					System.out.println("-- UPDATE EMPLOYEE --");
					System.out.println("Enter Employee ID: ");
					String search = (input.nextLine());
					employee.updateEmployee(emp).setId(search);
					System.out.println("Enter New Employee Name: ");
					employee.updateEmployee(emp).setName(input.nextLine());
					employee.createEmployee(employee.updateEmployee(emp));
					
					break;
				case "D": // Get an Employee's Data
					System.out.println("-- EMPLOYEE DETAILS --");
					System.out.println("Enter Employee ID: ");
					String findDetails = (input.nextLine());
					employee.getEmployeeDetails(findDetails);
					System.out.println("[1] Employee ID: " + employee.getEmployeeDetails(findDetails).getId());
					System.out.println("[2] Employee No.: " + employee.getEmployeeDetails(findDetails).getEmployeeNumber());
					System.out.println("[3] Employee ID: " + employee.getEmployeeDetails(findDetails).getName());
					break;
		
				case "E": // Get all of the Employee's Data
					System.out.println("-- ALL EMPLOYEE DETAILS --");

					for(Employee displayEmp : employee.getAllEmployees()) {
						System.out.println("[1] Employee ID: " + displayEmp.getId());
						System.out.println("[2] Employee No.: " + displayEmp.getEmployeeNumber());
						System.out.println("[3] Employee ID: " + displayEmp.getName());
					}
					break;
				
				default:
					// Base Case
					System.out.println("[SYSTEM ERROR]: INVALID INPUT!");
					break;
				
				
				}
				
				
				
			}
		}
	}

}
